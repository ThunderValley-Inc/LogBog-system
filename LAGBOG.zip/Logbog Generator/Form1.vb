﻿Public Class Form1
    Dim fag, side As String
    Dim Dansk1, Dansk2, Dansk3, Dansk4, Dansk5, Dansk6, Dansk7, Dansk8, Dansk9, Dansk10, Dansk11, Dansk12, Dansk13, Dansk14, Dansk15, Dansk16, Dansk17, Dansk18, Dansk19, Dansk20 As String
    Dim Biologi1, Biologi2, Biologi3, Biologi4, Biologi5, Biologi6, Biologi7, Biologi8, Biologi9, Biologi10, Biologi11, Biologi12, Biologi13, Biologi14, Biologi15, Biologi16, Biologi17, Biologi18, Biologi19, Biologi20 As String
    Dim Engelsk1, Engelsk2, Engelsk3, Engelsk4, Engelsk5, Engelsk6, Engelsk7, Engelsk8, Engelsk9, Engelsk10, Engelsk11, Engelsk12, Engelsk13, Engelsk14, Engelsk15, Engelsk16, Engelsk17, Engelsk18, Engelsk19, Engelsk20 As String

    Dim nummer As Integer

    Private Sub But_Dansk_Click(sender As Object, e As EventArgs) Handles But_Dansk.Click
        fag = "Dansk"
        side = "Dansk1"
        nummer = 1
        Txtbox_logbog.Text = Dansk1
        Lbl_kigger.Text = fag & " " & nummer

    End Sub

    Private Sub But_biologi_Click(sender As Object, e As EventArgs) Handles But_biologi.Click
        fag = "Biologi"
        side = "biologi1"
        nummer = 1
        Txtbox_logbog.Text = Biologi1
    End Sub

    Private Sub But_fordag_Click(sender As Object, e As EventArgs) Handles But_fordag.Click
        If nummer > 1 Then
            nummer = nummer - 1 'ændre hvilken dag vi kigger på
            side = fag & nummer 'regner ud hvilken siden den skal vise
        End If
        Select Case side
            Case "Dansk1"
                Txtbox_logbog.Text = Dansk1
            Case "Dansk2"
                Txtbox_logbog.Text = Dansk2
            Case "Dansk3"
                Txtbox_logbog.Text = Dansk3
            Case "Dansk4"
                Txtbox_logbog.Text = Dansk4
            Case "Dansk5"
                Txtbox_logbog.Text = Dansk5
            Case "Dansk6"
                Txtbox_logbog.Text = Dansk6
            Case "Dansk7"
                Txtbox_logbog.Text = Dansk7
            Case "Dansk8"
                Txtbox_logbog.Text = Dansk8
            Case "Dansk9"
                Txtbox_logbog.Text = Dansk9
            Case "Dansk10"
                Txtbox_logbog.Text = Dansk10
            Case "Dansk11"
                Txtbox_logbog.Text = Dansk11
            Case "Dansk12"
                Txtbox_logbog.Text = Dansk12
            Case "Dansk13"
                Txtbox_logbog.Text = Dansk13
            Case "Dansk14"
                Txtbox_logbog.Text = Dansk14
            Case "Dansk15"
                Txtbox_logbog.Text = Dansk15
            Case "Dansk16"
                Txtbox_logbog.Text = Dansk16
            Case "Dansk17"
                Txtbox_logbog.Text = Dansk17
            Case "Dansk18"
                Txtbox_logbog.Text = Dansk18
            Case "Dansk19"
                Txtbox_logbog.Text = Dansk19
            Case "Dansk20"
                Txtbox_logbog.Text = Dansk20
        End Select
        Lbl_kigger.Text = fag & " " & nummer
    End Sub

    Private Sub But_gem_Click(sender As Object, e As EventArgs) Handles But_gem.Click
        Select Case side
            Case "Dansk1"
                Dansk1 = Txtbox_logbog.Text
            Case "Dansk2"
                Dansk2 = Txtbox_logbog.Text
            Case "Dansk3"
                Dansk3 = Txtbox_logbog.Text
            Case "Dansk4"
                Dansk4 = Txtbox_logbog.Text
            Case "Dansk5"
                Dansk5 = Txtbox_logbog.Text
            Case "Dansk6"
                Dansk6 = Txtbox_logbog.Text
            Case "Dansk7"
                Dansk7 = Txtbox_logbog.Text
            Case "Dansk8"
                Dansk8 = Txtbox_logbog.Text
            Case "Dansk9"
                Dansk9 = Txtbox_logbog.Text
            Case "Dansk10"
                Dansk10 = Txtbox_logbog.Text
            Case "Dansk11"
                Dansk11 = Txtbox_logbog.Text
            Case "Dansk12"
                Dansk12 = Txtbox_logbog.Text
            Case "Dansk13"
                Dansk13 = Txtbox_logbog.Text
            Case "Dansk14"
                Dansk14 = Txtbox_logbog.Text
            Case "Dansk15"
                Dansk15 = Txtbox_logbog.Text
            Case "Dansk16"
                Dansk16 = Txtbox_logbog.Text
            Case "Dansk17"
                Dansk17 = Txtbox_logbog.Text
            Case "Dansk18"
                Dansk18 = Txtbox_logbog.Text
            Case "Dansk19"
                Dansk19 = Txtbox_logbog.Text
            Case "Dansk20"
                Dansk20 = Txtbox_logbog.Text
        End Select
    End Sub

    Private Sub But_nextday_Click(sender As Object, e As EventArgs) Handles But_nextday.Click
        If nummer < 20 Then
            nummer = nummer + 1
            side = fag & nummer
            Lbl_kigger.Text = side
        End If
        Select Case side
            Case "Dansk1"
                Txtbox_logbog.Text = Dansk1
            Case "Dansk2"
                Txtbox_logbog.Text = Dansk2
            Case "Dansk3"
                Txtbox_logbog.Text = Dansk3
            Case "Dansk4"
                Txtbox_logbog.Text = Dansk4
            Case "Dansk5"
                Txtbox_logbog.Text = Dansk5
            Case "Dansk6"
                Txtbox_logbog.Text = Dansk6
            Case "Dansk7"
                Txtbox_logbog.Text = Dansk7
            Case "Dansk8"
                Txtbox_logbog.Text = Dansk8
            Case "Dansk9"
                Txtbox_logbog.Text = Dansk9
            Case "Dansk10"
                Txtbox_logbog.Text = Dansk10
            Case "Dansk11"
                Txtbox_logbog.Text = Dansk11
            Case "Dansk12"
                Txtbox_logbog.Text = Dansk12
            Case "Dansk13"
                Txtbox_logbog.Text = Dansk13
            Case "Dansk14"
                Txtbox_logbog.Text = Dansk14
            Case "Dansk15"
                Txtbox_logbog.Text = Dansk15
            Case "Dansk16"
                Txtbox_logbog.Text = Dansk16
            Case "Dansk17"
                Txtbox_logbog.Text = Dansk17
            Case "Dansk18"
                Txtbox_logbog.Text = Dansk18
            Case "Dansk19"
                Txtbox_logbog.Text = Dansk19
            Case "Dansk20"
                Txtbox_logbog.Text = Dansk20
        End Select
        Lbl_kigger.Text = fag & " " & nummer
    End Sub
End Class
