﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.But_fordag = New System.Windows.Forms.Button()
        Me.But_nextday = New System.Windows.Forms.Button()
        Me.Txtbox_logbog = New System.Windows.Forms.TextBox()
        Me.But_gem = New System.Windows.Forms.Button()
        Me.Lbl_kigger = New System.Windows.Forms.Label()
        Me.Lbl_valgtfag = New System.Windows.Forms.Label()
        Me.But_Dansk = New System.Windows.Forms.Button()
        Me.But_english = New System.Windows.Forms.Button()
        Me.But_historie = New System.Windows.Forms.Button()
        Me.But_fysik = New System.Windows.Forms.Button()
        Me.But_kemi = New System.Windows.Forms.Button()
        Me.But_biologi = New System.Windows.Forms.Button()
        Me.But_Mat = New System.Windows.Forms.Button()
        Me.But_E1 = New System.Windows.Forms.Button()
        Me.But_E2 = New System.Windows.Forms.Button()
        Me.But_E3 = New System.Windows.Forms.Button()
        Me.But_E4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'But_fordag
        '
        Me.But_fordag.Location = New System.Drawing.Point(182, 45)
        Me.But_fordag.Name = "But_fordag"
        Me.But_fordag.Size = New System.Drawing.Size(75, 23)
        Me.But_fordag.TabIndex = 0
        Me.But_fordag.Text = "Forige Dag"
        Me.But_fordag.UseVisualStyleBackColor = True
        '
        'But_nextday
        '
        Me.But_nextday.Location = New System.Drawing.Point(559, 45)
        Me.But_nextday.Name = "But_nextday"
        Me.But_nextday.Size = New System.Drawing.Size(75, 23)
        Me.But_nextday.TabIndex = 1
        Me.But_nextday.Text = "Næste Dag"
        Me.But_nextday.UseVisualStyleBackColor = True
        '
        'Txtbox_logbog
        '
        Me.Txtbox_logbog.Location = New System.Drawing.Point(153, 120)
        Me.Txtbox_logbog.Multiline = True
        Me.Txtbox_logbog.Name = "Txtbox_logbog"
        Me.Txtbox_logbog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txtbox_logbog.Size = New System.Drawing.Size(582, 198)
        Me.Txtbox_logbog.TabIndex = 2
        '
        'But_gem
        '
        Me.But_gem.Location = New System.Drawing.Point(659, 335)
        Me.But_gem.Name = "But_gem"
        Me.But_gem.Size = New System.Drawing.Size(75, 23)
        Me.But_gem.TabIndex = 3
        Me.But_gem.Text = "Gem"
        Me.But_gem.UseVisualStyleBackColor = True
        '
        'Lbl_kigger
        '
        Me.Lbl_kigger.AutoSize = True
        Me.Lbl_kigger.Location = New System.Drawing.Point(345, 32)
        Me.Lbl_kigger.Name = "Lbl_kigger"
        Me.Lbl_kigger.Size = New System.Drawing.Size(88, 13)
        Me.Lbl_kigger.TabIndex = 4
        Me.Lbl_kigger.Text = "Fag dag Nummer"
        '
        'Lbl_valgtfag
        '
        Me.Lbl_valgtfag.AutoSize = True
        Me.Lbl_valgtfag.Location = New System.Drawing.Point(12, 9)
        Me.Lbl_valgtfag.Name = "Lbl_valgtfag"
        Me.Lbl_valgtfag.Size = New System.Drawing.Size(64, 13)
        Me.Lbl_valgtfag.TabIndex = 5
        Me.Lbl_valgtfag.Text = "Vælg dit fag"
        '
        'But_Dansk
        '
        Me.But_Dansk.Location = New System.Drawing.Point(15, 60)
        Me.But_Dansk.Name = "But_Dansk"
        Me.But_Dansk.Size = New System.Drawing.Size(75, 23)
        Me.But_Dansk.TabIndex = 6
        Me.But_Dansk.Text = "Dansk"
        Me.But_Dansk.UseVisualStyleBackColor = True
        '
        'But_english
        '
        Me.But_english.Location = New System.Drawing.Point(15, 89)
        Me.But_english.Name = "But_english"
        Me.But_english.Size = New System.Drawing.Size(75, 23)
        Me.But_english.TabIndex = 7
        Me.But_english.Text = "Engelsk"
        Me.But_english.UseVisualStyleBackColor = True
        '
        'But_historie
        '
        Me.But_historie.Location = New System.Drawing.Point(15, 118)
        Me.But_historie.Name = "But_historie"
        Me.But_historie.Size = New System.Drawing.Size(75, 23)
        Me.But_historie.TabIndex = 8
        Me.But_historie.Text = "Historie"
        Me.But_historie.UseVisualStyleBackColor = True
        '
        'But_fysik
        '
        Me.But_fysik.Location = New System.Drawing.Point(15, 148)
        Me.But_fysik.Name = "But_fysik"
        Me.But_fysik.Size = New System.Drawing.Size(75, 23)
        Me.But_fysik.TabIndex = 9
        Me.But_fysik.Text = "Fysik"
        Me.But_fysik.UseVisualStyleBackColor = True
        '
        'But_kemi
        '
        Me.But_kemi.Location = New System.Drawing.Point(15, 177)
        Me.But_kemi.Name = "But_kemi"
        Me.But_kemi.Size = New System.Drawing.Size(75, 23)
        Me.But_kemi.TabIndex = 10
        Me.But_kemi.Text = "Kemi"
        Me.But_kemi.UseVisualStyleBackColor = True
        '
        'But_biologi
        '
        Me.But_biologi.Location = New System.Drawing.Point(15, 32)
        Me.But_biologi.Name = "But_biologi"
        Me.But_biologi.Size = New System.Drawing.Size(75, 23)
        Me.But_biologi.TabIndex = 11
        Me.But_biologi.Text = "Biologi"
        Me.But_biologi.UseVisualStyleBackColor = True
        '
        'But_Mat
        '
        Me.But_Mat.Location = New System.Drawing.Point(15, 207)
        Me.But_Mat.Name = "But_Mat"
        Me.But_Mat.Size = New System.Drawing.Size(75, 23)
        Me.But_Mat.TabIndex = 12
        Me.But_Mat.Text = "Matematik"
        Me.But_Mat.UseVisualStyleBackColor = True
        '
        'But_E1
        '
        Me.But_E1.Location = New System.Drawing.Point(15, 236)
        Me.But_E1.Name = "But_E1"
        Me.But_E1.Size = New System.Drawing.Size(75, 23)
        Me.But_E1.TabIndex = 13
        Me.But_E1.Text = "Extrafag1"
        Me.But_E1.UseVisualStyleBackColor = True
        '
        'But_E2
        '
        Me.But_E2.Location = New System.Drawing.Point(15, 265)
        Me.But_E2.Name = "But_E2"
        Me.But_E2.Size = New System.Drawing.Size(75, 23)
        Me.But_E2.TabIndex = 14
        Me.But_E2.Text = "Extrafag2"
        Me.But_E2.UseVisualStyleBackColor = True
        '
        'But_E3
        '
        Me.But_E3.Location = New System.Drawing.Point(15, 295)
        Me.But_E3.Name = "But_E3"
        Me.But_E3.Size = New System.Drawing.Size(75, 23)
        Me.But_E3.TabIndex = 15
        Me.But_E3.Text = "Extrafag3"
        Me.But_E3.UseVisualStyleBackColor = True
        '
        'But_E4
        '
        Me.But_E4.Location = New System.Drawing.Point(15, 324)
        Me.But_E4.Name = "But_E4"
        Me.But_E4.Size = New System.Drawing.Size(75, 23)
        Me.But_E4.TabIndex = 16
        Me.But_E4.Text = "Extrafag 4"
        Me.But_E4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.But_E4)
        Me.Controls.Add(Me.But_E3)
        Me.Controls.Add(Me.But_E2)
        Me.Controls.Add(Me.But_E1)
        Me.Controls.Add(Me.But_Mat)
        Me.Controls.Add(Me.But_biologi)
        Me.Controls.Add(Me.But_kemi)
        Me.Controls.Add(Me.But_fysik)
        Me.Controls.Add(Me.But_historie)
        Me.Controls.Add(Me.But_english)
        Me.Controls.Add(Me.But_Dansk)
        Me.Controls.Add(Me.Lbl_valgtfag)
        Me.Controls.Add(Me.Lbl_kigger)
        Me.Controls.Add(Me.But_gem)
        Me.Controls.Add(Me.Txtbox_logbog)
        Me.Controls.Add(Me.But_nextday)
        Me.Controls.Add(Me.But_fordag)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents But_fordag As Button
    Friend WithEvents But_nextday As Button
    Friend WithEvents Txtbox_logbog As TextBox
    Friend WithEvents But_gem As Button
    Friend WithEvents Lbl_kigger As Label
    Friend WithEvents Lbl_valgtfag As Label
    Friend WithEvents But_Dansk As Button
    Friend WithEvents But_english As Button
    Friend WithEvents But_historie As Button
    Friend WithEvents But_fysik As Button
    Friend WithEvents But_kemi As Button
    Friend WithEvents But_biologi As Button
    Friend WithEvents But_Mat As Button
    Friend WithEvents But_E1 As Button
    Friend WithEvents But_E2 As Button
    Friend WithEvents But_E3 As Button
    Friend WithEvents But_E4 As Button
End Class
